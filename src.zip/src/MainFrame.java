import javax.swing.*;

public class MainFrame extends JFrame {


    public MainFrame() {
        add(new FormPanel());
        setTitle("SnakeGame");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
    }
}