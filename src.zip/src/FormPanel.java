import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Time;
import java.util.Random;

public class FormPanel extends JPanel implements ActionListener {
    static final int screenWidth = 600;
    static final int screenHeight = 600;
    static final int unitSize = 25;
    static final int gameUnits = (screenWidth * screenHeight) / unitSize;
    static final int delay = 75;
    final int x[] = new int[gameUnits];
    final int y[] = new int[gameUnits];
    int snakeBody = 6;
    int score = 0;
    int foodX;
    int foodY;
    char direction = 'R';
    boolean isRunning = false;
    Timer timer;
    Random random;


    public FormPanel() {
        random = new Random();
        this.setPreferredSize(new Dimension(screenHeight, screenWidth));
        this.setBackground(Color.BLACK);

        this.setFocusable(true);
        addKeyListener(new KeyAdapter());

        startGame();


    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {

        if (isRunning) {
            moveElements();
            checkApple();
            checkCollision();
        }
        repaint();
    }

    public void startGame() {
        newApple();
        isRunning = true;
        timer = new Timer(delay, this);
        timer.start();


    }
    public void restart(){
        startGame();
    }

    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        drawElements(graphics);

    }

    public void drawElements(Graphics graphics) {
        if (isRunning) {
            graphics.setColor(Color.RED);
            graphics.fillOval(foodX, foodY, unitSize, unitSize);

            for (int i = 0; i < snakeBody; i++) {
                if (i == 0) {
                    graphics.setColor(Color.green);
                    graphics.fillRect(x[i], y[i], unitSize, unitSize);
                } else {
                    graphics.setColor(new Color(45, 180, 0));
                    graphics.fillRect(x[i], y[i], unitSize, unitSize);
                }
            }
        } else {
            gameOver(graphics);

        }
    }

    public void moveElements() {
        for (int i = snakeBody; i > 0; i--) {
            x[i] = x[i - 1];
            y[i] = y[i - 1];
        }
        switch (direction) {
            case 'U':
                y[0] = y[0] - unitSize;
                break;
            case 'D':
                y[0] = y[0] + unitSize;
                break;
            case 'L':
                x[0] = x[0] - unitSize;
                break;
            case 'R':
                x[0] = x[0] + unitSize;
                break;
        }
    }

    public void newApple() {
        foodX = random.nextInt((int) (screenWidth / unitSize)) * unitSize;
        foodY = random.nextInt((int) (screenHeight / unitSize)) * unitSize;
    }

    public void checkCollision() {
        //If head collides with body
        for (int i = snakeBody; i > 0; i--) {
            if ((x[0] == x[i] && y[0] == y[i])) {
                isRunning = false;
            }
        }
        //Check if  snake touches left border
        if (x[0] < 0) {
            isRunning = false;
        }
        //Check if snake touches right border
        if (x[0] > screenWidth) {
            isRunning = false;
        }
        //Snake touches top border
        if (y[0] < 0) {
            isRunning = false;
        }
        //Snake touches bottom
        if (y[0] > screenHeight) {
            isRunning = false;
        }
        if (!isRunning) {
            timer.stop();
        }
    }

    public void checkApple() {
        if ((x[0] == foodX) && (y[0] == foodY)) {
            score++;
            snakeBody++;
            newApple();
        }

    }

    public void gameOver(Graphics graphics) {
        graphics.setColor(Color.RED);
        graphics.setFont(new Font("Ink Free", Font.BOLD, 50));
        FontMetrics metrics = getFontMetrics(graphics.getFont());
        graphics.drawString("Game Over", (screenWidth - metrics.stringWidth("Game Over")) / 2, screenHeight / 2);

        graphics.setColor(Color.RED.brighter());
        graphics.setFont(new Font("Ink Free", Font.BOLD, 25));
        metrics=getFontMetrics(graphics.getFont());
        graphics.drawString("Score:"+score,(screenWidth-metrics.stringWidth("Score:"))/3,screenHeight/3);

    }

    public class KeyAdapter extends java.awt.event.KeyAdapter {

        public void keyPressed(KeyEvent event) {
            switch (event.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    if (direction != 'R') {
                        direction = 'L';
                    }
                    break;
                case KeyEvent.VK_RIGHT:
                    if (direction != 'L') {
                        direction = 'R';
                    }
                    break;
                case KeyEvent.VK_UP:
                    if (direction != 'D') {
                        direction = 'U';
                    }
                    break;
                case KeyEvent.VK_DOWN:
                    if (direction != 'U') {
                        direction = 'D';
                    }
                    break;
                case KeyEvent.VK_ESCAPE:
                    timer.stop();
                    break;
                case KeyEvent.VK_ENTER:
                    timer.start();
                    break;
                case KeyEvent.VK_R:
                    startGame();
                    break;

            }


        }
    }

}
